<script setup>
import { defineAsyncComponent } from "vue";
const LogoDark = defineAsyncComponent(() => import('./LogoDark.vue'));
</script>
<template>
  <LogoDark />
</template>
