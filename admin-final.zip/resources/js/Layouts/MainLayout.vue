<script setup>
import { computed, defineAsyncComponent } from "vue"
import { usePage } from "@inertiajs/vue3"
import { useCustomizerStore } from '@/stores/customizer.js'
const VerticalSidebarVue = defineAsyncComponent(() => import('@/Layouts/vertical-sidebar/VerticalSidebar.vue'))
const VerticalHeaderVue = defineAsyncComponent(() => import('@/Layouts/vertical-header/VerticalHeader.vue'))
const FooterPanel = defineAsyncComponent(() => import('@/Layouts/footer/FooterPanel.vue'))

const customizer = useCustomizerStore()
const user = computed(() => usePage().props.user)
</script>
<template>
	<section v-if="user">
	  <v-locale-provider>
		<v-app
		  theme="PurpleTheme"
		  :class="[customizer.mini_sidebar ? 'mini-sidebar' : '']"
		>
		  <VerticalSidebarVue />
		  <VerticalHeaderVue />

		  <v-main>
			<v-container fluid class="page-wrapper">
            <div>
                <slot></slot>
            </div>
			</v-container>
			<v-container fluid class="pt-0">
			  <div>
				<FooterPanel />
			  </div>
			</v-container>
		  </v-main>
		</v-app>
	  </v-locale-provider>
	</section>
    <section v-else>
        <div>
            <slot></slot>
        </div>
    </section>
</template>
